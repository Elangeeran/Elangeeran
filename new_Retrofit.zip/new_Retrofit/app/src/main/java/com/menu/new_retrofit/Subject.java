package com.menu.new_retrofit;

import java.util.ArrayList;

public class Subject {
    public int id;
    public String subjectName;
    public ArrayList<Chapter> chapters;
}
