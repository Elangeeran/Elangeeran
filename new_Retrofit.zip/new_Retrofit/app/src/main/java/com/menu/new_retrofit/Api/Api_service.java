package com.menu.new_retrofit.Api;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api_service {
    @GET("users")
    Call<List<Movie>> getMovies();
}
