package com.menu.new_retrofit;

public class Chapter {
    public int id;
    public String chapterName;
    public String imageUrl;
}
