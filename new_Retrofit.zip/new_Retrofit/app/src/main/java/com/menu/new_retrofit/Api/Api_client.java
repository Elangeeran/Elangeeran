package com.menu.new_retrofit.Api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Api_client {
    public static String Base_Url = "https://jsonplaceholder.typicode.com/";
    private static Retrofit retrofit;
    public static Retrofit getclient(){
        if (retrofit == null){
            retrofit = new Retrofit.Builder ().baseUrl (Base_Url).addConverterFactory (GsonConverterFactory.create ()).build ();
        }
        return retrofit;
    }
}
