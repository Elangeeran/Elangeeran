package com.menu.new_retrofit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.menu.new_retrofit.Activity.Description_Activity;
import com.menu.new_retrofit.Api.Api_client;
import com.menu.new_retrofit.Api.Api_service;
import com.menu.new_retrofit.Api.Movie;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvSubject;
    private ArrayList<Subject> subjects;
    ArrayList<Movie> movieList;
    ChapterAdapter adapter;
    private ActionBarDrawerToggle t;
    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Toolbar toolbar = findViewById (R.id.toolbar);
        setSupportActionBar (toolbar);
        drawer = findViewById (R.id.drawer_layout);
        drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        NavigationView navigationView = findViewById (R.id.nav_view);
        t = new ActionBarDrawerToggle (this, drawer,R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener (t);
        t.syncState ();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener (new NavigationView.OnNavigationItemSelectedListener ( ) {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId ();
                switch (id){
                    case R.id.nav_home:
                        Toast.makeText(MainActivity.this, "My Account",Toast.LENGTH_SHORT).show();
                       // startActivity (new Intent ( getApplicationContext (), Description_Activity.class ));
                        break;
                    case(R.id.nav_category):
                        break;
                    case (R.id.nav_deal):
                        break;
                    case(R.id.nav_orders):
                        break;
                    case(R.id.nav_wishlist):
                        break;
                    case (R.id.nav_myaccount):
                        break;
                }
                drawer.closeDrawer (GravityCompat.START);
                return true;
            }
        });

        rvSubject = findViewById (R.id.rvSubject);
        LinearLayoutManager manager = new LinearLayoutManager(MainActivity.this);
        rvSubject.setLayoutManager(manager);
        Api_service apiService = Api_client.getclient ().create(Api_service.class);
        Call<List<Movie>> call = apiService.getMovies ();

        call.enqueue(new Callback<List<Movie>> () {
            @Override
            public void onResponse(Call<List<Movie>> call, Response<List<Movie>> response) {
                movieList = new ArrayList<> (response.body()  );
                for (Movie hero:movieList){
                    Log.v("moviesname",hero.getName ());
                }
                 adapter =new ChapterAdapter ( MainActivity.this, movieList, new ChapterAdapter.ListAdapterListener ( ) {
                     @Override
                     public void onClickAtOKButton(int position, List<Movie> movieList) {
                       //  Toast.makeText(getApplicationContext (), movieList.get ( position ).getName (), Toast.LENGTH_SHORT).show();
                         Intent intent=new Intent ( MainActivity.this,Description_Activity.class );
                         Bundle bundle = new Bundle (  );
                         bundle.putParcelableArrayList ("list",(ArrayList<?extends Parcelable>) movieList);
                         intent.putExtras (bundle);
                         startActivity ( intent );
                     }
                 });
                rvSubject.setAdapter (adapter);
            }

            @Override
            public void onFailure(Call<List<Movie>> call, Throwable t) {
                Log.d("TAG","Response = "+t.toString());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater ().inflate (R.menu.main_menu,menu);
        MenuItem search = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(search);
        search(searchView);
        return true;
    }
    private void search(SearchView searchView) {

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (adapter!=null)
                    adapter.getFilter().filter(newText);
                return true;
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(t.onOptionsItemSelected(item))
            return true;

        return super.onOptionsItemSelected(item);
    }
}
