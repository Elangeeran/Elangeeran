package com.menu.new_retrofit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.menu.new_retrofit.Api.Movie;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ChapterAdapter extends RecyclerView.Adapter<ChapterAdapter.CustomViewHolder> implements Filterable {

    private Context context;
    private ArrayList<Chapter> chapters;
    private LayoutInflater inflater;
    private ListAdapterListener mListener;
    ArrayList<Movie>movieList = new ArrayList<> (  );
    ArrayList<Movie>mArrayList = new ArrayList<> (  );

    public interface ListAdapterListener {
        void onClickAtOKButton(int position, List<Movie> movieList);
    }

    public ChapterAdapter(Context context,ArrayList<Movie> movieList,ListAdapterListener listener) {
        this.context = context;
        this.movieList = movieList;
        this.mArrayList=movieList;
        this.mListener=listener;
    }

    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_chapter, parent, false);
        return new CustomViewHolder (view);
    }

    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        Movie movie = movieList.get (position);
        holder.tvChapterName.setText(movie.getName ());
        holder.email.setText (movie.getEmail ());
        holder.itemView.setOnClickListener ( new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                Movie movie = movieList.get (position);
                List<Movie> newlist = new ArrayList<> (  );
                newlist.add (movie);
                mListener.onClickAtOKButton(position, newlist);
            }
        } );
    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter ( ) {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();

                if (charString.isEmpty()) {

                    movieList = mArrayList;
                } else {

                    ArrayList<Movie> filteredList = new ArrayList<>();

                    for (Movie carModel : mArrayList) {

                        if (carModel.getName().toLowerCase().contains(charString)) {

                            filteredList.add(carModel);
                        }
                    }

                    movieList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = movieList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults results) {
                movieList = (ArrayList<Movie>) results.values;
                notifyDataSetChanged();
            }
        };
    }


    public class CustomViewHolder extends RecyclerView.ViewHolder {


        public TextView tvChapterName,email;

        public CustomViewHolder(View itemView) {
            super(itemView);

            tvChapterName = (TextView) itemView.findViewById(R.id.tvChapterName);
            email = itemView.findViewById (R.id.email);
        }
    }
}
