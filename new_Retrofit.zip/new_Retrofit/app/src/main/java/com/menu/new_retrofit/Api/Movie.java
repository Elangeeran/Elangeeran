package com.menu.new_retrofit.Api;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Movie implements Parcelable {


    @SerializedName( "name" )
    @Expose
    private String name;

    @SerializedName( "email" )
    @Expose
    private String email;

    @SerializedName( "username" )
    @Expose
    private String username;

    @SerializedName( "phone" )
    @Expose
    private String phone;

    @SerializedName( "website" )
    @Expose
    private String website;

    @SerializedName ("street")
    @Expose
    private String street;


    public Movie(String name, String email, String username, String phone, String website,String street) {
        this.name = name;
        this.email = email;
        this.username = username;
        this.phone = phone;
        this.website = website;
        this.street = street;
    }

    protected Movie(Parcel in) {
        name = in.readString ( );
        email = in.readString ( );
        username = in.readString ( );
        phone = in.readString ( );
        website = in.readString ( );
        street = in.readString ();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie> ( ) {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie (in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getUsername() {
        return username;
    }

    public String getStreet() {
        return street;
    }

    public String getPhone() {
        return phone;
    }

    public String getWebsite() {
        return website;
    }



    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString (name);
        dest.writeString (email);
        dest.writeString (username);
        dest.writeString (phone);
        dest.writeString (website);
        dest.writeString (street);
    }
}
