package com.menu.new_retrofit.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.menu.new_retrofit.Api.Movie;
import com.menu.new_retrofit.R;

import java.util.ArrayList;

public class Description_Activity extends AppCompatActivity {
    private String  name,username,email,phoneno,website,company;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_description_);

        TextView name1=findViewById ( R.id.name );
        TextView realname1=findViewById ( R.id.username );
        TextView team1=findViewById ( R.id.email );
        TextView createdby1=findViewById ( R.id.phone );
        TextView appearance1=findViewById ( R.id.website );
        TextView bio1=findViewById ( R.id.company );

        Bundle extras = getIntent ().getExtras ();
        if(extras != null){
            ArrayList<Movie> myhero = extras.getParcelableArrayList ("list");
            Log.v ("heroes",myhero.get (0).getName () );


            name = myhero.get(0).getName ();
            username=myhero.get(0).getUsername ();
            email=myhero.get(0).getEmail ();
            phoneno=myhero.get(0).getPhone ();
            website=myhero.get(0).getWebsite ();
           company=myhero.get(0).getStreet ();

            name1.setText ( name );
            realname1.setText ( username);
            team1.setText ( email );
            createdby1.setText ( phoneno);
            appearance1.setText ( website );
            bio1.setText ( company );

    }
}}