package com.menu.restarent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.menu.restarent.List_item.constants;
import com.menu.restarent.menu_database.Menu_Dao;
import com.menu.restarent.menu_database.Menu_database;
import com.menu.restarent.menu_database.Menu_details;
import com.menu.restarent.menu_database.Nonveg;
import com.menu.restarent.menu_database.Veg_details;

import java.util.ArrayList;
import java.util.List;

public class table extends AppCompatActivity {

    Menu_database menu_database;
    List<Menu_details>menu_details;
    Menu_details menu_details1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
      menu_database = Menu_database.getInstance (getApplicationContext ());
      menu_database.menu_dao ().insertDetails (menu_details1);
    }
     private List<Menu_details>builditemlist(){
        List<Menu_details>menu_details= new ArrayList<> (  );
        menu_details1 = new Menu_details (1,"Vegetarian",buildsubitem());
        menu_details.add (menu_details1);
        return menu_details;
     }
  private List<Veg_details>buildsubitem(){
        List<Veg_details>veg_details = new ArrayList<> (  );
        Veg_details veg_details1 = new Veg_details ("munchoorian");
        veg_details.add (veg_details1);
        return veg_details;
  }
}

