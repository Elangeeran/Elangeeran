package com.menu.restarent.menu_database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface Menu_Dao {

    @Query ("SELECT *FROM menuItem")
    List<Menu_details> getallmenu();

    @Query("SELECT * FROM menuItem ORDER BY ID")
    List<Menu_details> loadAllPersons();


    @Query("SELECT * FROM menuItem where dish_Type= :dishtype ")
    int alreadyexisttype(String dishtype);

    @Insert(onConflict = REPLACE)
    void insertDetails(Menu_details menuDetails);



    @Update
    void update(Menu_details menuItem);

    @Query ("delete from menuItem")
    void deleteAllData();

    @Query("SELECT * FROM menuItem WHERE id = :id")
    Menu_details loadPersonById(int id);

    @Query ("SELECT * FROM  Nonveg")
    List<Nonveg>getallnon();

    @Query("SELECT * FROM Nonveg where dish_name= :dishname ")
    int alreadynonexists(String dishname);

    @Query ("SELECT * FROM Nonveg where dish_name= :dishname")
    Nonveg getnonveg_item(String dishname);

    @Insert(onConflict = REPLACE)
    void insertdata(Nonveg details);

    @Update
    void update(Nonveg details);

    @Query ("SELECT * FROM  VEGETARIAN")
    List<Veg_details>getall();


    @Query("SELECT * FROM vegetarian where dish_name= :dishname ")
    int alreadyvegexist(String dishname);

    @Query ("SELECT * FROM vegetarian where dish_name= :dishname")
    Veg_details getveg_item(String dishname);

    @Insert(onConflict = REPLACE)
    void insertdata(Veg_details details);

    @Update
    void update(Veg_details details);


}
