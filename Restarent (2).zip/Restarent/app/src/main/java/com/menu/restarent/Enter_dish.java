package com.menu.restarent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.menu.restarent.List_item.constants;
import com.menu.restarent.menu_database.Menu_Dao;
import com.menu.restarent.menu_database.Menu_database;
import com.menu.restarent.menu_database.Menu_details;
import com.menu.restarent.menu_database.Nonveg;
import com.menu.restarent.menu_database.Veg_details;

public class Enter_dish extends AppCompatActivity {

    EditText category ,subcat1, subcat2,subcat3;
    Button submit ,submit2,submit3,submit4;
    Menu_database menu_database;
    Menu_Dao menu_dao;
    Intent intent;
    int mPersonId;
    Menu_details menu_details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_enter_dish);

        category = findViewById (R.id.editTextText);
        subcat1 = findViewById (R.id.editText2);
        subcat2 = findViewById (R.id.editText3);
        subcat3 = findViewById (R.id.editText4);
        submit = findViewById (R.id.button);
        submit2 = findViewById (R.id.button2);
        submit3 = findViewById (R.id.button3);
        submit4 = findViewById (R.id.button4);

        menu_database = Menu_database.getInstance (Enter_dish.this);
        intent =getIntent ();
        if (intent != null && intent.hasExtra(constants.UPDATE_Person_Id)) {

            mPersonId = intent.getIntExtra(constants.UPDATE_Person_Id, -1);

            AppExecutor.getInstance().diskIO().execute(new Runnable() {
                @Override
                public void run() {
                    Menu_details person = menu_database.menu_dao ().loadPersonById (mPersonId);
                    populateUI(person);
                }
            });
        }



        submit.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {

                String categor = category.getText ().toString ().trim();
                if (categor.isEmpty ()){
                    Toast.makeText (getApplicationContext (),"Enter data",Toast.LENGTH_SHORT).show ();
                }
                else {
                    AppExecutor.getInstance ().diskIO ().execute (new Runnable ( ) {
                        @Override
                        public void run() {
                            if (((menu_database.menu_dao ( ).alreadyexisttype (categor)) == 0)) {
                                 menu_details = new Menu_details (categor);
                                menu_database.menu_dao ( ).insertDetails (menu_details);
                                runOnUiThread (new Runnable ( ) {
                                    @Override
                                    public void run() {
                                        Toast.makeText (getApplicationContext ()," data ADD successfully",Toast.LENGTH_SHORT).show ();

                                    }
                                });
                            } else {
                                runOnUiThread (new Runnable ( ) {
                                    @Override
                                    public void run() {
                                        Toast.makeText (getApplicationContext ( ), "Already Added", Toast.LENGTH_SHORT).show ( );

                                    }
                                });
                            }
                        }
                    });
                }

            }
        });


        submit2.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                String subcatagory1 = subcat1.getText ().toString ().trim ();

                if (subcatagory1.isEmpty ()){
                    Toast.makeText (getApplicationContext (),"Enter data",Toast.LENGTH_SHORT).show ();

                }
                else {
                    AppExecutor.getInstance ().diskIO ().execute (new Runnable ( ) {
                        @Override
                        public void run() {
                            if ((menu_database.menu_dao ().alreadyvegexist (subcatagory1))==0){
                                Veg_details veg_details = new Veg_details (subcatagory1);
                                menu_database.menu_dao ().insertdata (veg_details);
                                runOnUiThread (new Runnable ( ) {
                                    @Override
                                    public void run() {
                                        Toast.makeText (getApplicationContext ()," data successfully",Toast.LENGTH_SHORT).show ();

                                    }
                                });
                            }
                            else {
                                runOnUiThread (new Runnable ( ) {
                                    @Override
                                    public void run() {
                                        Toast.makeText (getApplicationContext ()," Already added ",Toast.LENGTH_SHORT).show ();
                                    }
                                });

                            }
                        }
                    });
                }
            }
        });

        submit3.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                String subcatagory2 = subcat2.getText ().toString ().trim ();

                if (subcatagory2.isEmpty ()){
                    Toast.makeText (getApplicationContext (),"Enter data",Toast.LENGTH_SHORT).show ();

                }
                else {
                    AppExecutor.getInstance ().diskIO ().execute (new Runnable ( ) {
                        @Override
                        public void run() {
                            if ((menu_database.menu_dao ().alreadynonexists (subcatagory2))==0){
                                Nonveg nonveg = new Nonveg (subcatagory2);
                                menu_database.menu_dao ().insertdata (nonveg);
                                runOnUiThread (new Runnable ( ) {
                                    @Override
                                    public void run() {
                                        Toast.makeText (getApplicationContext ()," data successfully",Toast.LENGTH_SHORT).show ();

                                    }
                                });
                            }
                            else {
                                Toast.makeText (getApplicationContext ()," Already added ",Toast.LENGTH_SHORT).show ();
                            }
                        }
                    });
                }
            }
        });
        Button next = findViewById (R.id.nextpage);

        next.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent ( Enter_dish.this, Menucard.class );

                startActivity (intent);
            }
        });

    }



    private void populateUI(Menu_details person) {

        if (person == null) {
            return;
        }
        category.setText(person.getDish_Type ());
    }
}