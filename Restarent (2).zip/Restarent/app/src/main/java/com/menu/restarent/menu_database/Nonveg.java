package com.menu.restarent.menu_database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "Nonveg")
public class Nonveg {

    @PrimaryKey(autoGenerate = false)
    int id;

    @ColumnInfo(name = "dish_name")
    String dish_name;

    @ColumnInfo(name = "dish_qty")
    int qty;

    public Nonveg(String dish_name) {
        this.id = id;
        this.dish_name = dish_name;
        this.qty = qty;
    }

    @Ignore
    public Nonveg(String dish_name, int qty) {
        this.dish_name = dish_name;
        this.qty = qty;
    }

    public int getId() {
        return id;
    }

    public String getDishname() {
        return dish_name;
    }
}
