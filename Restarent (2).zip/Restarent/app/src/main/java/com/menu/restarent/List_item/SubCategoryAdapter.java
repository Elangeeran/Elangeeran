package com.menu.restarent.List_item;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.menu.restarent.R;
import com.menu.restarent.menu_database.Menu_database;
import com.menu.restarent.menu_database.Menu_details;
import com.menu.restarent.menu_database.Veg_details;

import java.util.List;

public class SubCategoryAdapter extends RecyclerView.Adapter<SubCategoryAdapter.viewHolder> {

    private Context context;
    private List<Veg_details> veg_menu;
    private List<Menu_details> menudata;




    public interface  ListAdapterListeners{
        void onClickAtOKButton(int position, List<Veg_details> List);
    }

    public SubCategoryAdapter(Context context, List<Veg_details> veg_menu) {
        this.context = context;
        this.veg_menu = veg_menu;

    }

    @NonNull
    @Override
    public SubCategoryAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.activity_reset_password,parent,false);

        viewHolder viewholder =new viewHolder (view);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {
        Veg_details veg_details = veg_menu.get (position);

            holder.textView.setText (veg_details.getDish_name ());

    }

    @Override
    public int getItemCount() {
        return veg_menu.size ();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        TextView textView;

        public viewHolder(@NonNull View itemView) {
            super (itemView);
            textView =itemView.findViewById (R.id.txtsubCategory2);
        }
    }
}
