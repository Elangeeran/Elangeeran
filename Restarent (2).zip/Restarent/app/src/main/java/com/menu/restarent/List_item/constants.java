package com.menu.restarent.List_item;

public class constants {
    public static final String UPDATE_Person_Id = "update_task";
}
