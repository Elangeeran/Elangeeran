package com.menu.restarent.List_item;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.TransitionManager;

import com.menu.restarent.Logindetails;
import com.menu.restarent.R;
import com.menu.restarent.menu_database.Menu_database;
import com.menu.restarent.menu_database.Menu_details;
import com.menu.restarent.menu_database.Nonveg;
import com.menu.restarent.menu_database.Veg_details;

import java.util.ArrayList;
import java.util.List;

public class Adapterclass extends RecyclerView.Adapter<Adapterclass.MyViewHolder> {
    private Context context;
    private List<Menu_details> menudata;
    ListAdapterListener listener;
    private List<Veg_details> subCatList;
    private List<Nonveg> subCatList2;
    int mExpandedPosition =-1;
    String veg = "VEG";



    public interface ListAdapterListener {
        void onClickAtOKButton(int position, List<Menu_details> List);
    }


    public Adapterclass(Context context,List<Menu_details>menudata, List<Veg_details> subCatList, ListAdapterListener listener) {
        this.context = context;
        this.menudata = menudata;
        this.subCatList = subCatList;
        this.listener=listener;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_view, parent, false);

        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }


    @Override
    public void onBindViewHolder(@NonNull Adapterclass.MyViewHolder holder, int position) {

              Menu_details menu_details = menudata.get (position);
        holder.txtCategory.setText (menu_details.getDish_Type ());

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager (context);
        holder.recycleSubList.setLayoutManager (linearLayoutManager);
        holder.recycleSubList.setHasFixedSize (true);

        child_Adapterclass adapter = new child_Adapterclass (context,subCatList, new child_Adapterclass.ListAdapterListeners ( ) {
            @Override
            public void onClickAtOKButton(int position, List<Veg_details> List) {
            }
        });
        holder.recycleSubList.setAdapter (adapter);

        final boolean isExpanded = position==mExpandedPosition;
        holder.recycleSubList.setVisibility(isExpanded?View.VISIBLE:View.GONE);
        holder.itemView.setActivated(isExpanded);

        if (isExpanded)
            mExpandedPosition = position;
        if(isExpanded){
        holder.arrow.setImageResource (R.drawable.ic_baseline_expand_less_24);}

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Menu_details menu_details1 = menudata.get (position);
                List<Menu_details>list = new ArrayList<> (  );
                list.add (menu_details1);
                listener.onClickAtOKButton(position, list);
                holder.recycleSubList.setVisibility (View.VISIBLE);

                mExpandedPosition = isExpanded ? -1:position;
                notifyItemChanged(mExpandedPosition);
                holder.arrow.setImageResource (R.drawable.ic_baseline_expand_more_24);
                notifyItemChanged(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        if (menudata == null) {
            return 0;
        }
        return menudata.size();

    }




    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtCategory;
        ImageView arrow;
        RecyclerView recycleSubList;
        private View subItem;

        public MyViewHolder(@NonNull View itemView)  {
            super ( itemView );
            txtCategory=itemView.findViewById (R.id.txtCategory);
           recycleSubList = itemView.findViewById (R.id.recycleSublist);
            subItem = itemView.findViewById(R.id.sub_item);
             arrow = itemView.findViewById (R.id.expandview);
        }


    }
}