package com.menu.restarent.menu_database;

import android.content.Context;
import android.os.Build;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


@Database (entities = {Menu_details.class,Veg_details.class,Nonveg.class},version = 1,exportSchema = false)
public abstract class Menu_database extends RoomDatabase {

    private static final String Db_name = "menu_data";
    private static Menu_database Instance;

    public synchronized static Menu_database getInstance(Context context){
        if (Instance==null){
            Instance = Room.databaseBuilder (context.getApplicationContext (),Menu_database.class,Db_name)
                    .enableMultiInstanceInvalidation ().build ();

        }
        return Instance;
    }
    public abstract Menu_Dao menu_dao();

}
