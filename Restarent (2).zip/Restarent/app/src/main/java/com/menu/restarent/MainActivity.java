package com.menu.restarent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Context;
import android.content.Intent;
import android.location.GnssAntennaInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.menu.restarent.LoginDao;

import java.util.List;


public class MainActivity extends AppCompatActivity  {

    EditText emailid,password,name,confirmpassword;
    ImageButton Register;
    TextView clickhere;
    LoginDao db;
    LoginDatabase appDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main2);
        name = findViewById(R.id.name);
        emailid = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmpassword = findViewById(R.id.password2);
        Register = findViewById(R.id.signup);

         appDb = LoginDatabase.getInstance (MainActivity.this);

        Button signin = findViewById(R.id.signin);
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Loginpage.class));
            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if (name.getText ().toString ().trim ().isEmpty () || emailid.getText ().toString ().trim ().isEmpty () ){
                    Toast.makeText (getApplicationContext (),"All Field is Mandatotry",Toast.LENGTH_SHORT).show ();
                }
                else {

                    AppExecutor.getInstance ().diskIO ().execute (new Runnable ( ) {
                        @Override
                        public void run() {
                            if(appDb.loginDao ().alreadyexist (emailid.getText ().toString ().trim ())==0) {
                                Logindetails logindetails = new Logindetails (emailid.getText ( ).toString ( ).trim ( ),
                                        password.getText ( ).toString ( ).trim ( ), name.getText ( ).toString ( ).trim ( ));

                                appDb.loginDao ( ).insertDetails (logindetails);
                                runOnUiThread (new Runnable ( ) {
                                    @Override
                                    public void run() {
                                        Toast.makeText (getApplicationContext (),"Registered Successfully",Toast.LENGTH_SHORT).show ();

                                    }
                                });

                                Intent intent1 = new Intent ( MainActivity.this,Loginpage.class );
                                startActivity (intent1);

                            }
                            else {
                                runOnUiThread (new Runnable ( ) {
                                    @Override
                                    public void run() {
                                        Toast.makeText (getApplicationContext (),"Already Registered",Toast.LENGTH_SHORT).show ();
                                    }
                                });

                                Intent intent = new Intent ( MainActivity.this,Loginpage.class );
                                startActivity (intent);
                            }

                               //Toast.makeText (getApplicationContext (), "Data saved successfully", Toast.LENGTH_SHORT).show ();

                            List<Logindetails> logindetailsList =  appDb.loginDao ().getAll ();



                            for(int i= 0;i<logindetailsList.size ();i++){
                                Log.i ("log_data",logindetailsList.get (i).getId ()+"=="+logindetailsList
                                        .get (i).getEmail ()+"=="+logindetailsList.get (i).getUserName ()+"=="+logindetailsList.get (i).getPassword ());

                            }}



                    });



                }

            }


        });


    }



}



