package com.menu.restarent.List_item;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.menu.restarent.R;
import com.menu.restarent.menu_database.Menu_Dao;
import com.menu.restarent.menu_database.Menu_database;
import com.menu.restarent.menu_database.Nonveg;
import com.menu.restarent.menu_database.Veg_details;

import java.util.List;

public class child2display extends AppCompatActivity {
    private Menu_database mdb;
    private Veg_details veg_details;
    private Menu_Dao menuDao;
    private List<Veg_details>dishlist;
    private List<Nonveg>nondish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_menucard);



    }

    }
