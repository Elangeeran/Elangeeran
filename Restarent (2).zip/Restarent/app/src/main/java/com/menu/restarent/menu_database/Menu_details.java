package com.menu.restarent.menu_database;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.List;

@Entity(tableName = "menuItem")
public class Menu_details  {

    @PrimaryKey(autoGenerate = true)
    private int id;


    @ColumnInfo(name ="dish_Type")
    private String dish_Type;

    public Menu_details(String dish_Type) {
        this.id = id;
        this.dish_Type = dish_Type;

    }


    @Ignore
    public Menu_details(int i, String dish_Type, List<Veg_details> buildsubitem) {
        this.dish_Type = dish_Type;
    }

    public void setId(int id) {
        this.id = id;
    }



    public void setDish_Type(String dish_Type) {
        this.dish_Type = dish_Type;
    }

    public int getId() {
        return id;
    }

    public String getDish_Type() {
        return dish_Type;
    }


}

/*class category{
    @ColumnInfo(name = "id")
    int id;

    @Relation (parentColumn = "id",entityColumn = "category",entity = Veg_details.class)
    List<Veg_details>veg_details;

}*/
