package com.menu.restarent;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Loginpage extends AppCompatActivity {
    EditText editTextEmail, editTextPassword;
    ImageButton buttonLogin;
   // LoginDao db;
    TextView forgotpass;
    Button signinlog;
   // LoginDatabase dataBase;
    String emailid;
    private static final String DB_NAME = "person_db";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_loginpage2);

        editTextEmail = findViewById(R.id.emaillog);
        editTextPassword = findViewById(R.id.passwordlog);
        buttonLogin = findViewById(R.id.login);
        signinlog = findViewById (R.id.signinlog);
        //forgotpass = findViewById (R.id.forgotpassword);



        buttonLogin.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {

                if (editTextEmail.getText ().toString ().trim ().isEmpty () ){
                    Toast.makeText (getApplicationContext (),"Enter email ",Toast.LENGTH_SHORT).show ();
                }
                if ( editTextPassword.getText ().toString ().trim ().isEmpty () ){
                    Toast.makeText (getApplicationContext (),"Enter password",Toast.LENGTH_SHORT).show ();
                }
                else{
                    LoginDatabase loginDatabase = LoginDatabase.getInstance (getApplicationContext ());
                    final LoginDao loginDao = loginDatabase.loginDao ();

                    AppExecutor.getInstance ().diskIO ().execute (new Runnable ( ) {
                        @Override
                        public void run() {
                           final String email = editTextEmail.getText ().toString ().trim ();
                            final String password = editTextPassword.getText ().toString ().trim ();

                            Logindetails logindetailsList=  loginDao.login_check (email,password);

                                if (logindetailsList!= null) {

                                        Intent i = new Intent (Loginpage.this, table.class);
                                        startActivity (i);

                                    }

                                else {

                                    runOnUiThread (new Runnable ( ) {
                                        @Override
                                        public void run() {
                                            Toast.makeText(Loginpage.this, "Check your email and password", Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                }
                                }

                    });
                }


            }

            private boolean isvalidpassword(String password) {

                final String PASSWORD_PATTERN = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
                Pattern pattern = Pattern.compile (PASSWORD_PATTERN , Pattern.CASE_INSENSITIVE  );
                Matcher matcher = pattern.matcher (password);
                return matcher.matches ();

            }

            private boolean isEmailValid(String emailid) {
                String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
                Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(emailid);
                return  matcher.matches ();
            }
        });
        signinlog.setOnClickListener (new View.OnClickListener ( ) {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent ( Loginpage.this,MainActivity.class );
                startActivity (intent1);
            }
        });

        /* forgotpass.setOnClickListener (new View.OnClickListener ( ) {
             @Override
             public void onClick(View v) {
                 Intent intent = new Intent ( Loginpage.this,Reset_password.class );
                 startActivity (intent);
             }
         });*/
    }

    }

