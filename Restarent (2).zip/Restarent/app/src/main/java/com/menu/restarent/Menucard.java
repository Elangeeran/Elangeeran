package com.menu.restarent;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.menu.restarent.List_item.Adapterclass;
import com.menu.restarent.List_item.child2display;
import com.menu.restarent.menu_database.Menu_Dao;
import com.menu.restarent.menu_database.Menu_database;
import com.menu.restarent.menu_database.Menu_details;
import com.menu.restarent.menu_database.Veg_details;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Menucard extends AppCompatActivity {


  private LinearLayoutManager linearLayoutManager;
  private static RecyclerView recyclerView;
  List<Menu_details>datalist;
  List<Veg_details> subCatList;
  ExecutorService service = Executors.newSingleThreadExecutor ();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_menucard);



        recyclerView = findViewById (R.id.recyclerView);
        recyclerView.setHasFixedSize (true);
        linearLayoutManager = new LinearLayoutManager (Menucard.this);
        recyclerView.setLayoutManager (linearLayoutManager);
        recyclerView.setItemAnimator (new DefaultItemAnimator ());
        recyclerView.setNestedScrollingEnabled(true);

        Menu_database menu_database = Menu_database.getInstance (getApplicationContext ());

        Menu_Dao menu_dao =menu_database.menu_dao ();


        AppExecutor.getInstance ().diskIO ().execute (new Runnable ( ) {
            @Override
            public void run() {
                datalist = menu_dao.getallmenu ();
                subCatList = menu_dao.getall ();


                Adapterclass adapterclass = new Adapterclass (getApplicationContext ( ), datalist, subCatList, new Adapterclass.ListAdapterListener ( ) {
                    @Override
                    public void onClickAtOKButton(int position, List<Menu_details> List) {
                        Toast.makeText (getApplicationContext (),datalist.get (position).getDish_Type (),Toast.LENGTH_SHORT).show ();
                    }
                });
                 runOnUiThread (new Runnable ( ) {
                     @Override
                     public void run() {
                         recyclerView.setAdapter (adapterclass);
                     }
                 });
            }

        });

    }
}