package com.menu.restarent.List_item;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.menu.restarent.R;
import com.menu.restarent.menu_database.Menu_database;
import com.menu.restarent.menu_database.Menu_details;
import com.menu.restarent.menu_database.Nonveg;
import com.menu.restarent.menu_database.Veg_details;

import java.util.ArrayList;
import java.util.List;

public class child_Adapterclass extends RecyclerView.Adapter<child_Adapterclass.viewHolder> {

    private Context context;
    private List<Veg_details>veg_menu;
    ListAdapterListeners  listener;
    private List<Menu_details> menudata;
    int mExpandedPosition =-1;
    private LayoutInflater layoutInflater;
    public interface  ListAdapterListeners{
        void onClickAtOKButton(int position, List<Veg_details> List);
    }

    public child_Adapterclass(Context context, List<Veg_details> veg_menu , ListAdapterListeners listener) {
        this.context = context;
        this.veg_menu = veg_menu;
        this.listener = listener;
        this.layoutInflater = LayoutInflater.from(context);
    }


    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from (parent.getContext ()).inflate (R.layout.animate_recycler,parent,false);

        viewHolder viewholder =new viewHolder (view);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {

        Veg_details veg_details = veg_menu.get (position);
       // Nonveg nonveg =nonvegList.get (position);
            List<Veg_details>veg_menus =new ArrayList<> (  );

            holder.textView.setText (veg_details.getDish_name ());


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager (context);
        holder.recycleSubList2.setLayoutManager (linearLayoutManager);
        holder.recycleSubList2.setHasFixedSize (true);

        SubCategoryAdapter adapter = new SubCategoryAdapter (context,veg_menu);
        holder.recycleSubList2.setAdapter (adapter);


        final boolean isExpanded = position==mExpandedPosition;
        holder.recycleSubList2.setVisibility(isExpanded?View.VISIBLE:View.GONE);
        holder.itemView.setActivated(isExpanded);

        if (isExpanded)
            mExpandedPosition = position;
        if(isExpanded){
            holder.arrow.setImageResource (R.drawable.ic_baseline_expand_less_24);}

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mExpandedPosition = isExpanded ? -1:position;
                notifyItemChanged(mExpandedPosition);
                holder.arrow.setImageResource (R.drawable.ic_baseline_expand_more_24);
                notifyItemChanged(position);
            }
        });

            }




    @Override
    public int getItemCount() {
        return veg_menu.size ();
    }


    public class viewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        Menu_database menu_database;
        RecyclerView recycleSubList2;
        ImageView arrow;

        public viewHolder(@NonNull View itemView) {
            super (itemView);
            textView =itemView.findViewById (R.id.childname);
            recycleSubList2 = itemView.findViewById (R.id.recycleSublist2);
            arrow = itemView.findViewById (R.id.expandview);
        }
    }
}
