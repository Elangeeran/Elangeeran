package com.menu.restarent;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface LoginDao {

    @Query("SELECT * FROM persondata")
    List<Logindetails> getAll();


    @Query("SELECT * FROM persondata where email= :email ")
   int alreadyexist(String email);

    @Query("SELECT * FROM persondata where email= :email and password= :password ")
    Logindetails login_check(String email,String password);

    @Insert(onConflict = REPLACE)
    void insertDetails(Logindetails persondata);

    @Update
    void update(Logindetails persondata);

    @Query ("delete from persondata")
    void deleteAllData();
}
