package com.menu.restarent;


import android.content.Context;
import android.util.Log;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities= {Logindetails.class},exportSchema = false, version=1)
public  abstract class LoginDatabase extends RoomDatabase {
    private static final String DB_NAME = "person_db";
    private static LoginDatabase instance;
   public synchronized static LoginDatabase getInstance(Context context){
        if (instance == null){
            instance = Room.databaseBuilder (context.getApplicationContext (),LoginDatabase.class,DB_NAME)
                    .fallbackToDestructiveMigration ()
                    .build ();
        }
       return instance;
    }
    public abstract LoginDao loginDao();
}

