package com.menu.restarent.menu_database;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "vegetarian")
public class Veg_details  {

    @PrimaryKey(autoGenerate = true)
    int id;

    @ColumnInfo(name = "dish_name")
    String dish_name;

    public Veg_details(int id, String dish_name) {
        this.id = id;
        this.dish_name = dish_name;
    }

    @Ignore
    public Veg_details(String dish_name) {
        this.dish_name = dish_name;
    }

    public int getId() {
        return id;
    }

    public String getDish_name() {
        return dish_name;
    }
}
